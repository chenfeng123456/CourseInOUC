1. 先看看 gongxi.mtx 文件。大致上和 M-Tx 文档里边说的没多大差别，只是要说清楚中文字体：

TeX: \font\scm="Songti SC" at 10pt
TeX: \largemusicsize\scm

注意，不要照抄我的代码，除非你的机上也有 Songti SC 这套字体。用你惯用的字体名称就好了，用英文名称保险些。


2. 用 musixtex 命令行编译这个 .mtx，并说明是要用 xelatex:

musixtex -t -F "xetex" gongxi.mtx

一切顺利的话你会发现生成了一个 gongxi.tex，还有一个 gongxi.pdf，有中文的！如果你的目的只是生成这个五线谱 .pdf，恭喜，可以打印了。完成，收工。



又或者你是想把五线谱插入另一个 LaTeX 文件？两种做法。

* 偷懒做法：用 \includegraphics 或者 \includepdf (看 pdfpages 宏包)，直接插入生成好的 gongxi.pdf。完成，收工。


4. 正经八百做法：请看 foo.tex。导言区比较重要的几行：

\usepackage{mtxlatex}  %% mtxlatex.sty 必须手动放到同一路径下，比较方便
\mtxlatex

\usepackage[no-math]{fontspec}  %% no-math 很重要！不然会起冲突！
\usepackage{ctex}

然后 \input{gongxi}，就是刚才第2步里 musixtex 生成的 gongxi.tex。


5. 如常 xelatex 编译：

xelatex foo

如果一切顺利，你就会看到五线谱出现在 PDF 里了！喜大普奔！诶？等等怎么右边有很不协调的空白？

6. 好，这是宽度还没调好呢。注意看一下，你的文件夹里应该又生成了一个 foo.mx1 档。命令行执行：

musixflx foo.mx1 (或者 musixflx foo 就好)

7. 最后再次 xelatex 编译：

xelatex foo


好了这次真是喜大普奔了，完成，收工！
